<template>
    <inertia-link href="/" class="text-5xl inline">
        <span class="text-white">Simpl</span><span class="text-red-600">@</span>
    </inertia-link>
</template>
