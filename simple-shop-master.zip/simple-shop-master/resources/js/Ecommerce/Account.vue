<template>
    <a href="/login">
        <button
            class="inline-block relative group items-center text-center cursor-pointer focus:outline-none mr-4"
        >
            <i class="fas fa-user text-xl"></i>
            <p>Account</p>
        </button>
    </a>
</template>
