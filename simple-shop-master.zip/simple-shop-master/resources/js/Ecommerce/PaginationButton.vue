<template>
    <div
        class="
                p-2 border flex items-center justify-center cursor-pointer hover:text-white hover:bg-blue-600
            "
    >
        <slot></slot>
    </div>
</template>

<script>
    export default {

    }
</script>