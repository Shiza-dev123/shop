<template>
    <div id="footer" class="p-6 box-border w-full text-white bg-gray-700">
        <div class="container grid grid-cols-4 gap-4 m-auto">
            <div class="text-xl font-semibold">
                <a href="">About</a>
            </div>
            <div class="text-xl font-semibold">
                <a href="">Order and delivery</a>
            </div>
            <div class="text-xl font-semibold">
                <a href="">Customer support</a>
            </div>
            <div class="text-xl font-semibold">
                <a href="/">Simpl<span class="text-red-600">@</span></a>
            </div>
        </div>
        <div class="text-center text-xs mt-3">Created by:
            <a
                href="https://sarkozibalazs.dev"
                target="_blank"
                class="text-blue-300"
            >
                Sárközi Balázs
            </a>
        </div>
    </div>
</template>
